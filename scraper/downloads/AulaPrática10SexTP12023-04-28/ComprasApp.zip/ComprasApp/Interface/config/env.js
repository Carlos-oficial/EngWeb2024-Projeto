module.exports.apiAccessPoint = "http://localhost:8001/api"
